#ifndef load_account_cpp
#define load_account_cpp
#include<iostream>
#include<fstream>
#include<string>
#include<windows.h>
using namespace std;

//globalized function
void load_account()       //struct and variables
  {
  	struct customerInfo
  {
	  int password;
	  string name;

  }record[2];
	int count=0;
	ifstream DATAFILE;                            //readinf file with ifstream
	DATAFILE.open("account.txt", ios::in);
	if(!DATAFILE)
	{
		cout<<"\t\tError: database file cannot be accessed."<<endl;
	}
	else
	{
		while(!DATAFILE.eof())
		{
			DATAFILE>>record[count].name                    
			        >>record[count].password;
					
            count++;
		}
		DATAFILE.close();
	}
	system("pause");
  }
  #endif  //globalized function
