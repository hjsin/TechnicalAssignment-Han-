#ifndef update_account_cpp
#define update_account_cpp
#include<iostream>
#include<fstream>
#include<string>
#include<windows.h>
using namespace std;

//globalized function
void update_account()
  {
  	//struct and variables
  	struct customerInfo
  {
	  int password;
	  string name;

  }record[2];
	int i, j, k, line=0, count=0, temppassword ;
	string tempname;
	ifstream DATAFILE_READ;                                           //reading file with ifstream
	DATAFILE_READ.open("account.txt", ios::in);
	if(!DATAFILE_READ)
	{
		cout<<cout<<"\t\tError: customerInfo file cannot be accessed."<<endl;
		return;
	}
	else
	{
		while(!DATAFILE_READ.eof())
		{
			DATAFILE_READ>>record[count].name
			             >>record[count].password;                         //displaying current file
						 
            line = count + 1;
            cout<<"\t\tSlot: " <<line<<"->"
                <<"\t\t"<<record[count].name<<" "<<endl
				<<"\t\t\t"<<record[count].password<<endl
				
				<<"\t\t======================\n";
            count++;
        }
        DATAFILE_READ.close();
        ofstream DATAFILE_WRITE;
        DATAFILE_WRITE.open("account.txt", ios::out);               //choosing slots
        cout<<"\t\t--Which slot do you want to update?--"<<endl;
        cin>>j;
        k = j - 1;
        
		system("cls");    
        cout<<"\t\tEnter new name               : ";              //inputing new information
        cin>>tempname;
        cout<<"\t\tEnter new password           : ";
        cin>>temppassword;
        
        record[k].name = tempname;
        record[k].password = temppassword;
        
        for(i=0; i<count; i++)
        {
   	 		 DATAFILE_WRITE<<endl<<record[i].name                       //updating the data
	  			        	<<endl<<record[i].password;
		}
		cout<<"\t\t--Data Updated--"<<endl;                             //data updated
		DATAFILE_WRITE.close();
	}
	system("pause");
  }
  #endif //globalized function
