#ifndef display_account_cpp
#define display_account_cpp
#include<iostream>
#include<fstream>
#include<string>
#include<windows.h>
using namespace std;

//globalized function
void display_account() 
  {
  	//struct variables
  	struct customerInfo
  {
	  int password;
	  string name;

  }record[2];
	int i=0;
	ifstream DATAFILE;                        //reading file with ifstream
	DATAFILE.open("account.txt", ios::in);
	if(!DATAFILE)
	{
		cout<<"\t\tError: customerInfo file cannot be accessed."<<endl;   //error possibility
		return;
	}
	else
	{
		cout<<"\t\t--Customer Information-- \n";
		while(!DATAFILE.eof())
		{
		  	DATAFILE>>record[i].name                        //displaying read file
			        >>record[i].password
			      
					;
            cout<<"\t\tName               : "<<record[i].name<<endl
                <<"\t\tPassword           : "<<record[i].password<<endl
			
				<<"\t\t=================================\n\n";
            i++;
	    }
	    cout<<"\t\t--End of file--"<<endl;
	    DATAFILE.close();
	}
    system("pause");
  }
  #endif //globalized function
