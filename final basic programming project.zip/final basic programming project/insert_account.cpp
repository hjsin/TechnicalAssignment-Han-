#ifndef insert_account_cpp
#define insert_account_cpp
#include<iostream>
#include<fstream>
#include<string>
#include<windows.h>
using namespace std;

//globalized function
void insert_account()     
    { 
    //struct and variables
    struct customerInfo
  {
	  int password;
	  string name;

  }record[2];
	int password;
	string name;                                  //using ofstream to input data into file
	
	ofstream DATAFILE; 
	DATAFILE.open("account.txt", ios::app);
	if(!DATAFILE)
	{
		cout<<"\t\tError: customerInfo file cannot be accessed."<<endl;
		return;
	}
	else
	{
		cout<<"\t\t--Insert New Data--"<<endl<<endl;   //inserts new data
		cout<<"\t\tName               : ";
		cin>>name;
		cin.ignore();
		cout<<"\t\tPassword        : ";
		cin>>password;
		
		
		DATAFILE<<endl<<name
                <<endl<<password;
                
                
        cout<<"\t\t--New Data Inserted--"<<endl;
        DATAFILE.close();
                
	}
	system("pause");
  } 
  #endif //globalized function
