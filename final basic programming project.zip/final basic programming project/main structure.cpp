#include<iostream>
#include<fstream>
#include<string>
#include <stdlib.h>
#include<windows.h>
#include "bmi.cpp"
#include "pulserate.cpp"
#include "hearing.cpp"
#include "color.cpp"
#include "certification.cpp"
#include "username.cpp"

// the main program structure
int main()
{
	int input;
	//Interface
	system ("color D");
	cout<<"#######################################################################################################################\n";
	cout<<"#######################################################################################################################\n";
	cout<<"#######                                                                                                         #######\n";
	cout<<"#######                        WELCOME  TO  THE  FSKPM  AUTOMATED  HEALTH  CHECK-UP                             #######\n";
	cout<<"#######                                                                                                         #######\n";
	cout<<"#######                            Please select the following buttons to start                                 #######\n";
    cout<<"#######                                                                                                         #######\n";
	cout<<"#######                                     (eg: input = 1 , 2 , 3)                                             #######\n";
	cout<<"#######                                                                                                         #######\n";
	cout<<"#######################################################################################################################\n";
	cout<<"#######################################################################################################################\n\n";

	      cout<<"         ****************************                                      **************************** \n";    
	      cout<<"         **                        **                                      **                        ** \n";
	      cout<<"         **    1)   BMI TEST       **                                      **  4) MANAGE ACCOUNT     ** \n";
	      cout<<"         **                        **                                      **                        ** \n";
	      cout<<"         ****************************                                      **************************** \n"; 
	      
	      cout<<"         ****************************                                      **************************** \n"; 
	      cout<<"         **                        **                                      **                        ** \n";
	      cout<<"         **  2)  HEARING TEST      **                                      **   5)   PULSE RATE      ** \n";
	      cout<<"         **                        **                                      **                        ** \n";
	      cout<<"         ****************************                                      **************************** \n"; 
	      
	      cout<<"         ****************************                                      **************************** \n";
		  cout<<"         **                        **                                      **                        ** \n";
		  cout<<"         **  3)    EYE TEST        **                                      ** 6) PRINT CERTIFICATE   ** \n";
		  cout<<"         **                        **                                      **                        ** \n"; 
	      cout<<"         ****************************                                      **************************** \n"; 
	
	
	cin>>input;
	cout<<"LOADING..."<<endl;
//	Sleep(2000);
	system("cls");
	
	   // switch starts here 
  switch(input) 
  {
       // Hearing test
  	case 1:
  	  	
  	bmi();
  	system ("cls");
  	main();
  	  	
  	  	
	break;
	  
	    // Pulse rate test
	 	case 2:
	 		
		hearing ();
		system ("cls");
		main();
  	  	
		
	    break;
		 
		// Bmi test
	    	 case 3:
	    		
       		 color();
       		 system ("cls");
       		 main();
  	  	     

        	 break;
	   
	   //manage account
	    			case 4:
  	  	
					username();
					system ("cls");
       				main();	 
	 	   	
	  				break;
	  
	  //pulse rate test
	  						case 5:
  	  	
							pulserate();
							system ("cls");
       						main();
	 	   	
	  						break;
	  
	  //printing certificate
	  								case 6:
  	  	
									certification();
									system ("cls");
       								main();
	 	   	
	  								break;
	  
  }
  

	
	system ("pause");
	return 0; 
}

