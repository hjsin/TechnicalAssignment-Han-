#ifndef bmi_cpp
#define bmi_cpp
#include<iostream>
#include<fstream>
#include<string>
#include<windows.h>

using namespace std;
//globalized function
void bmi ()
{   //variables
	float weight, height, total_height, bmi;
    char again;
do
  {  

	system ("color E");
	cout<<"******************************Welcome to the BMI Test****************************\n";
	cout<<"                           Please input your weight (kg) :                       \n";              
	cin>>weight;
	cout<<"                           Please input your height (cm) :                       \n";
	cin>>height;
	
	// calculate height
	height = height / 100;
	
	// calculate total_height
	total_height = (height * height) ;
	
	// calculate BMI
	bmi = (weight / total_height) ;
	
	cout<<" Your BMI is : "<<bmi<<endl;
	std::ofstream outfile;                   //print text for certificate later

    outfile.open("certification.txt", std::ios_base::app);
    outfile << "Your BMI is :"<<bmi<<endl;
	
	
	//step 1	//displaying results
	if ( bmi < 18.5 )
	{
		cout<<" You are Underweight "<<endl;
		
		 //step 2
		if ( bmi < 18.5)
		{		                     //Using ifstream to read text file
        ifstream read_from_file;
        read_from_file.open("Underweight.txt");
    
        string Underweight;
                
        while( read_from_file >> Underweight)
        {
           cout<<"Explaination :  " <<Underweight<<endl;           
        }
        cout<<endl;
        
        read_from_file.close();
        }
   	}
   	
   	
   	
	else if ( bmi >= 18.5 && bmi < 24.9 )
	{
		cout<<" You are Normal "<<endl;
		 //step 2
		if ( bmi >= 18.5 && bmi < 24.9 )
		{		
        ifstream read_from_file;
        read_from_file.open("Normal.txt");
    
        string Normal;        
        
        while( read_from_file >> Normal)
        {
           cout<<"Explaination :  " <<Normal<<endl;           
        }
        cout<<endl;
        
        read_from_file.close();
        }
   	}
   	
		
		
	else if ( bmi >= 25.0 && bmi < 29.9 )
	{
		cout<<" You are Overweight "<<endl;
		//step 2
		if ( bmi >= 25.0 && bmi < 29.9 )
		{		
        ifstream read_from_file;
        read_from_file.open("Overweight.txt");
    
        string Overweight;        
        
        while( read_from_file >> Overweight)
        {
           cout<<"Explaination :  " <<Overweight<<endl;           
        }
        cout<<endl;
        
        read_from_file.close();
        }
   	}
		
	
	
	else if ( bmi >= 30.0 && bmi < 34.9 )
	{
		cout<<" You are Class I Obesity "<<endl;
		//step 2
		if ( bmi >= 30.0 && bmi < 34.9 )
		{		
        ifstream read_from_file;
        read_from_file.open("Obesity_I.txt");
    
        string Obesity_I;        
        
        while( read_from_file >> Obesity_I )
        {
           cout<<"Explaination :  " <<Obesity_I<<endl;           
        }
        cout<<endl;
        
        read_from_file.close();
        }
   	}
		
	
	
	else if ( bmi >= 35.0 && bmi < 39.9)
	{
		cout<<" You are Class II Obesity "<<endl;
		//step 2
		if ( bmi >= 35.0 && bmi < 39.9 )
		{		
        ifstream read_from_file;
        read_from_file.open("Obesity_II.txt");
    
        string Obesity_II;        
        
        while( read_from_file >> Obesity_II )
        {
           cout<<"Explaination :  " <<Obesity_II<<endl;           
        }
        cout<<endl;
        
        read_from_file.close();
        }
   	}
   	
   	
   	
	else if ( bmi >= 40.0 )
	{
		cout<<" You are Class III Obesity "<<endl;//step 2
		if ( bmi >= 40.0 )
		{		
        ifstream read_from_file;
        read_from_file.open("Obesity_III.txt");
    
        string Obesity_III;        
        
        while( read_from_file >> Obesity_III )
        {
           cout<<"Explanation :  " <<Obesity_III<<endl;           
        }
        cout<<endl;
        
        read_from_file.close();
        }   	
	}// while and do function to repeat
		cout<<"(Press 'y' if you want to repeat and press 'n' if you do not want to repeat)";
		cin>>again;
		
    }while ( again == 'y' || again == 'Y');

    cout<<"LOADING..."<<endl;
	Sleep(2000);       //slows down the system
	
}
#endif     //globalized function
