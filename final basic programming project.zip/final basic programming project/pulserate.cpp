#ifndef pulserate_cpp
#define pulserate_cpp
#include<iostream>
#include<windows.h>
#include<fstream>
using namespace std;

//globalized function
void pulserate ()
{
	//variables
	int age, total_pulse_rate, pulse_rate;
    char again;
do
{
	system("color E");
	cout<<"**************************Welcome to the Pulse Rate Test*************************\n\n";
	cout<<"                       Turn the hand with palm-side facing up.                   \n";
	cout<<"         Place your index finger and middle finger just below the thumb.         \n";
	cout<<"     Exert sight pressure with the index and second finger against the wrist bone.\n";
	cout<<"             Please count the pulse for 30 seconds using watch or clock.        \n\n";
	cout<<"                           Please enter your pulse rate :                         \n";
	cin>>pulse_rate;
	cout<<"                              Please enter your age:                              \n";
	cin>>age;
	
	
	//calculation
	total_pulse_rate = pulse_rate*2;
	//results
	cout<<"You have a total pulse rate of :" <<total_pulse_rate<< " beats per minute\n\n";
	std::ofstream outfile;                                               //print text for certificate later

    outfile.open("certification.txt", std::ios_base::app);
    outfile << "Your pulse rate is :"<<total_pulse_rate<<" beats per minute "<<endl;
	
	//comment on results
	if ( age >= 18    &&    age < 25 )
	{
			if( total_pulse_rate >48 && total_pulse_rate <56)
			{
				cout<<"You are an athlete!"<<endl;
			}
			else if( total_pulse_rate >55 && total_pulse_rate <62)
			{
				cout<<"You are in an excellent condition!"<<endl;
			}
			else if( total_pulse_rate >61 && total_pulse_rate <66)
			{
				cout<<"You are in a good condition!"<<endl;
			}
			else if( total_pulse_rate >65 && total_pulse_rate <70)
			{
				cout<<"You are above average!"<<endl;
			}
			else if( total_pulse_rate >69 && total_pulse_rate <74)
			{
				cout<<"You are average!"<<endl;
			}
			else if( total_pulse_rate >73 && total_pulse_rate <82)
			{
				cout<<"You are below average!"<<endl;
			}
			else if ( total_pulse_rate >81 )
			{
				cout<<"You have a poor pulse rate!"<<endl;
			}

	}
	else if ( age >= 26 &&  age < 35 )
	{
		if( total_pulse_rate >48 && total_pulse_rate <55)
			{
				cout<<"You are an athlete!"<<endl;
			}
			else if( total_pulse_rate >54 && total_pulse_rate <62)
			{
				cout<<"You are in an excellent condition!"<<endl;
			}
			else if( total_pulse_rate >61 && total_pulse_rate <66)
			{
				cout<<"You are in a good condition!"<<endl;
			}
			else if( total_pulse_rate >65 && total_pulse_rate <71)
			{
				cout<<"You are above average!"<<endl;
			}
			else if( total_pulse_rate >70 && total_pulse_rate <75)
			{
				cout<<"You are average!"<<endl;
			}
			else if( total_pulse_rate >74 && total_pulse_rate <82)
			{
				cout<<"You are below average!"<<endl;
			}
			else if ( total_pulse_rate >81 )
			{
				cout<<"You have a poor pulse rate!"<<endl;
			}	
	}
	
	else if ( age >= 36 &&  age < 45 )
	{
		if( total_pulse_rate >49 && total_pulse_rate <57)
			{
				cout<<"You are an athlete!"<<endl;
			}
			else if( total_pulse_rate >56 && total_pulse_rate <63)
			{
				cout<<"You are in an excellent condition!"<<endl;
			}
			else if( total_pulse_rate >62 && total_pulse_rate <67)
			{
				cout<<"You are in a good condition!"<<endl;
			}
			else if( total_pulse_rate >66 && total_pulse_rate <71)
			{
				cout<<"You are above average!"<<endl;
			}
			else if( total_pulse_rate >70 && total_pulse_rate <76)
			{
				cout<<"You are average!"<<endl;
			}
			else if( total_pulse_rate >75 && total_pulse_rate <83)
			{
				cout<<"You are below average!"<<endl;
			}
			else if ( total_pulse_rate >82 )
			{
				cout<<"You have a poor pulse rate!"<<endl;
			}	
	}
	
	else if ( age >= 46 &&  age < 55 )
	{
		if( total_pulse_rate >49 && total_pulse_rate <58)
			{
				cout<<"You are an athlete!"<<endl;
			}
			else if( total_pulse_rate >57 && total_pulse_rate <64)
			{
				cout<<"You are in an excellent condition!"<<endl;
			}
			else if( total_pulse_rate >63 && total_pulse_rate <68)
			{
				cout<<"You are in a good condition!"<<endl;
			}
			else if( total_pulse_rate >69 && total_pulse_rate <72)
			{
				cout<<"You are above average!"<<endl;
			}
			else if( total_pulse_rate >71 && total_pulse_rate <76)
			{
				cout<<"You are average!"<<endl;
			}
			else if( total_pulse_rate >75 && total_pulse_rate <84)
			{
				cout<<"You are below average!"<<endl;
			}
			else if ( total_pulse_rate >83 )
			{
				cout<<"You have a poor pulse rate!"<<endl;
			}	
	}
	
	else if ( age >= 56 &&  age < 65 )
	{
		if( total_pulse_rate >50 && total_pulse_rate <57)
			{
				cout<<"You are an athlete!"<<endl;
			}
			else if( total_pulse_rate >56 && total_pulse_rate <63)
			{
				cout<<"You are in an excellent condition!"<<endl;
			}
			else if( total_pulse_rate >62 && total_pulse_rate <68)
			{
				cout<<"You are in a good condition!"<<endl;
			}
			else if( total_pulse_rate >67 && total_pulse_rate <72)
			{
				cout<<"You are above average!"<<endl;
			}
			else if( total_pulse_rate >71 && total_pulse_rate <77)
			{
				cout<<"You are average!"<<endl;
			}
			else if( total_pulse_rate >76 && total_pulse_rate <82)
			{
				cout<<"You are below average!"<<endl;
			}
			else if ( total_pulse_rate >81 )
			{
				cout<<"You have a poor pulse rate!"<<endl;
			}	
	}

	else if ( age > 66 )
		{
		if( total_pulse_rate >49 && total_pulse_rate <56)
			{
				cout<<"You are an athlete!"<<endl;
			}
			else if( total_pulse_rate >55 && total_pulse_rate <62)
			{
				cout<<"You are in an excellent condition!"<<endl;
			}
			else if( total_pulse_rate >61 && total_pulse_rate <66)
			{
				cout<<"You are in a good condition!"<<endl;
			}
			else if( total_pulse_rate >65 && total_pulse_rate <70)
			{
				cout<<"You are above average!"<<endl;
			}
			else if( total_pulse_rate >69 && total_pulse_rate <74)
			{
				cout<<"You are average!"<<endl;
			}
			else if( total_pulse_rate >73 && total_pulse_rate <80)
			{
				cout<<"You are below average!"<<endl;
			}
			else if ( total_pulse_rate >79 )
			{
				cout<<"You have a poor pulse rate!"<<endl;
			}	
	}
	// while and do function to repeat
	cout<<"(Press 'y' if you want to repeat and press 'n' if you do not want to repeat)";
		cin>>again;
		
}while ( again == 'y' || again == 'Y');
	cout<<"LOADING..."<<endl;
	Sleep(2000);
	
}
#endif //globalized function
