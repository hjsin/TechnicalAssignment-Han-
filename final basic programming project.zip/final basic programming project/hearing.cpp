#ifndef hearing_cpp
#define hearing_cpp
#include<iostream>
#include<windows.h>
#include<string>
#include<fstream>
using namespace std;
//globalized function
void hearing ()
{
	//variables
	int eight, ten, twelve, fourteen, sixteen, eighteen, twenty, twentytwo; 
    char again;
    int hearmarks;
    string line;
do
{   //instructions
	system("color C");
	cout<<"**************************Welcome to the Hearing Test*************************\n\n" ;
	cout<<" For every sound frequency, please input whether you are able to hear the sound\n";
	cout<<"                        Select the number as follows                           \n\n";
	cout<<"                          If you hear the sound : 1                            \n";
	cout<<"                       If you do not hear the sound : 2                        \n";
	
// sound at 8 khz	
	cout<<"The following sound is at 8kHz\n";
	cout<<"Press anything to load the sound file\n";
	system ("pause");
	system ("8000.m4r");
	cout<<"Please select your number:";       //input
	cin>>eight;
	//Results
	if( eight == 1)
	{
		cout<<"You can hear this. Please proceed to the next frequency\n";  
	}
	else if (eight == 2)
	{
		std::ofstream outfile;                                    //print text for certificate later

         outfile.open("certification.txt", std::ios_base::app);         
        outfile << "You better get your ears checked immediately:"<<endl;
		cout<<"You cant hear this. Please proceed to the next frequency\n";
		string eightss;
	ifstream myfile ("8khz.txt");           //using ifstream to retrieve text from file
	while(getline (myfile,eightss))
	{
		cout<<eightss<<'\n';
	}
	myfile.close();
		cout<<"going back to main page\n";
		cout<<"LOADING..."<<endl;
        Sleep(5000);
        return;
		
	}
	
// sound at 10 khz
	cout<<"The following sound is at 10kHz\n";
	cout<<"Press anything to load the sound file\n";
	system ("pause");
	system ("10000.m4r");
	cout<<"Please select your number:";
	cin>>ten;
	if( ten == 1)
	{
		cout<<"You can hear this. Please proceed to the next frequency\n";
	}
	else if ( ten == 2)
	{
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "Your ears are sixty years and older"<<endl;
		cout<<"You cant hear this. Please proceed to the next frequency\n";
		string tenss;
	ifstream myfile ("10khz.txt");
	while(getline (myfile,tenss))
	{
		cout<<"RESULTS:"<<tenss<<'\n';
	}
	myfile.close();
		cout<<"going back to main page\n";
		cout<<"LOADING..."<<endl;
        Sleep(5000);
        return;
	}

// sound at 12 khz
	cout<<"The following sound is at 12kHz\n";
	cout<<"Press anything to load the sound file\n";
	system ("pause");
	system ("12000.m4r");
	cout<<"Please select your number:";
	cin>>twelve;
	if( twelve == 1)
	{
		cout<<"You can hear this. Please proceed to the next frequency\n";
	}
	else if ( twelve == 2)
	{
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "Your ears are 50 years and older"<<endl;
		cout<<"You cant hear this. Please proceed to the next frequency\n";
		string twelvess;
	ifstream myfile ("12khz.txt");
	while(getline (myfile,twelvess))
	{
		cout<<"RESULTS:"<<twelvess<<'\n';
	}
	myfile.close();
		cout<<"going back to main page\n";
		cout<<"LOADING..."<<endl;
        Sleep(5000);
        return;
	}
    
// sound at 14 khz    
	cout<<"The following sound is at 14kHz\n";
	cout<<"Press anything to load the sound file\n";
	system ("pause");
	system ("14000.m4r");
	cout<<"Please select your number:";
	cin>>fourteen;
	if( fourteen == 1)
	{
		cout<<"You can hear this. Please proceed to the next frequency\n";
	}
	else if (fourteen == 2)
	{
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "Your ears are 45 years and older"<<endl;
		cout<<"You cant hear this. Please proceed to the next frequency\n";
		string fourteenss;
	ifstream myfile ("14khz.txt");
	while(getline (myfile,fourteenss))
	{
		cout<<"RESULTS:"<<fourteenss<<'\n';
	}
	myfile.close();
		cout<<"going back to main page\n";
		cout<<"LOADING..."<<endl;
        Sleep(5000);
        return;
	}
	
// sound at 16 khz
	cout<<"The following sound is at 16kHz\n";
	cout<<"Press anything to load the sound file\n";
	system ("pause");
	system ("16000.m4r");
	cout<<"Please select your number:";
	cin>>sixteen;
	if( sixteen == 1)
	{
		cout<<"You can hear this. Please proceed to the next frequency\n";
	}
	else if (sixteen == 2)
	{
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "Your ears are 30 years and older"<<endl;
		cout<<"You cant hear this. Please proceed to the next frequency\n";
		string sixteenss;
	ifstream myfile ("16khz.txt");
	while(getline (myfile,sixteenss))
	{
		cout<<"RESULTS:"<<sixteenss<<'\n';
	}
	myfile.close();
		cout<<"going back to main page\n";
		cout<<"LOADING..."<<endl;
        Sleep(5000);
        return;
		
	}

// sound at 18 khz
	cout<<"The following sound is at 18kHz\n";
	cout<<"Press anything to load the sound file\n";
	system ("pause");
	system ("18000.m4r");
	cout<<"Please select your number:";
	cin>>eighteen;
	if( eighteen == 1)
	{
		cout<<"You can hear this. Please proceed to the next frequency\n";
	}
	else if (eighteen == 2)
	{
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "Your ears are 24 years and older"<<endl;
		cout<<"You cant hear this. Please proceed to the next frequency\n";
		string eighteenss;
	ifstream myfile ("18khz.txt");
	while(getline (myfile,eighteenss))
	{
		cout<<"RESULTS:"<<eighteenss<<'\n';
	}
	myfile.close();
		cout<<"going back to main page\n";
		cout<<"LOADING..."<<endl;
        Sleep(5000);
        return;
	}

// sound at 20 khz
	cout<<"The following sound is at 20kHz\n";
	cout<<"Press anything to load the sound file\n";
	system ("pause");
	system ("20000.m4r");
	cout<<"Please select your number:";
	cin>>twenty;
	if( twenty == 1)
	{
		cout<<"You can hear this. Please proceed to the next frequency\n";
	}
	else if (twenty == 2)
	{
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "Your ears are 24 years and older"<<endl;
		cout<<"You cant hear this. Please proceed to the next frequency\n";
		string twentyss;
	ifstream myfile ("20khz.txt");
	while(getline (myfile,twentyss))
	{
		cout<<"RESULTS:"<<twentyss<<'\n';
	}
	myfile.close();
		cout<<"going back to main page\n";
		cout<<"LOADING..."<<endl;
        Sleep(5000);
        return;
	}

// sound at 22 khz
	cout<<"The following sound is at 22kHz\n";
	cout<<"Press anything to load the sound file\n";
	system ("pause");
	system ("22000.m4r");
	cout<<"Please select your number:";
	cin>>twentytwo;
	if( twentytwo == 1)
	{
		cout<<"You can hear this. Please proceed to the next frequency\n";
	}
	else if (twentytwo == 2)
	{
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "Your ears are 18 years and older"<<endl;
		cout<<"You cant hear this. Please proceed to the next frequency\n";
		string twentytwoss;
	ifstream myfile ("22khz.txt");
	while(getline (myfile,twentytwoss))
	{
		cout<<"RESULTS:"<<twentytwoss<<'\n';
	}
	myfile.close();
		cout<<"going back to main page\n";
		cout<<"LOADING..."<<endl;
        Sleep(5000);
        return;
    }
        // while and do function to repeat	
    	cout<<"(Press 'y' if you want to repeat and press 'n' if you do not want to repeat)";
		cin>>again;
	
  }while ( again == 'y' || again == 'Y');
  cout<<"LOADING"<<endl;
  Sleep(2000);

  
}
#endif //globalized function
