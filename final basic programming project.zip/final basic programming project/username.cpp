#ifndef username_cpp
#define username_cpp
#include<iostream>
#include<fstream>
#include<string>
#include<windows.h>
#include "load_account.cpp"
#include "display_account.cpp"
#include "insert_account.cpp"
#include "update_account.cpp"
using namespace std;

//struct and variables
  struct customerInfo
  {
	  int password;
	  string name;

  }record[2];
//globalized function
void username()
{   //variables
	int select;
	char toContinue;
	toContinue = 'y';
	while(toContinue == 'y')
	{
		system("cls");
		system("color B");
		//main menu
		cout<<"******************************Manage your Account********************************\n";
	    cout<<"\t\tMain Menu"<<endl
		    <<"\t\t\n"
		    <<"\t\t1. Display account information \n\n\n"
		    <<"\t\t2. Insert new information \n\n\n"
		    <<"\t\t3. Update account information \n\n\n"
		    <<"\t\t4. Quit\n\n\n"
			<<"\t\t Press 1 to 4 to select.\n";
		     cin>>select;    
	
            //switch starts from here
               switch(select)
  			   {
		            case 1: system("cls");
		  	            display_account();         //displays account data
		  	            break;
                    case 2: system("cls");
  	                    insert_account();          //inserts new account data
					    break;
     				case 3: system("cls");
   	 			        update_account();          //changes current account data
				        break;
				    case 4:  return;               //returns to homepage
					  cout<<"LOADING"<<endl;
                      Sleep(2000);
                      break;
               }
            
	}

}
#endif //globalized function

