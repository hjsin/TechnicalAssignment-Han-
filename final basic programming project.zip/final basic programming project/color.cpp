#include<iostream>
#ifndef color_cpp
#define color_cpp
#include<string>
#include<stdlib.h>
#include<windows.h>
#include<fstream>
using namespace std;
//variables
int i,j,k=1;
int answer1, answer2, answer3 ;
int input, inputcolor, inputcolor2, colormarks, color1, color2, color3, totalcolour, colour1, colour2;
 //globalized function
void color()
{
	cout<<"**************************Welcome to the Eye Test*************************\n" ;
	cout<<"     For us to check your eyesight. Kindly choose one of the options below\n" ;
	cout<<"                        Enter the following number                        \n" ;
	cout<<"                          Eye Color Test : 1                              \n" ;         //option between test 1 or test 2
	cout<<"                          Eye Shape Test : 2                              \n" ;
	    cin>>input;
	    
	    system("cls");
	  
	 
	  switch(input)
	  { //color test starts here
	      case 1:
	    
	      	cout<<" Thanks for choosing the Eye Color Test\n";
	      	Sleep(2000);
	      	system("cls");
	    
            system("color C");
	      	cout<<" * * * *     * * * *    * * * *   * * * *   **      * "<<endl;
	      	cout<<" *           *     *    *         *         * *     * "<<endl;
  	      	cout<<" *           *     *    *         *         *  *    * "<<endl;
	      	cout<<" *   * * *   * * * *    * * * *   * * * *   *   *   * "<<endl;
	      	cout<<" *     *     *  *       *         *         *    *  * "<<endl;
	      	cout<<" * * * *     *   *      *         *         *     * * "<<endl;
	      	cout<<"       *     *    *     * * * *   * * * *   *      ** "<<endl;
	      	cout<<" Now, please input the color that you see\n";      //input
	      	cout<<" Select '1' for Green\n";
	      	cout<<"        '2' for Red\n";
	      	cout<<"        '3' for Blue\n";
	      	cout<<"        '4' for Yellow\n";
	      	cin>>inputcolor;
	      	system("CLS");
	      	//Result
	      	if( inputcolor == 2)
	      	{
	      		cout<<"That is absolutely correct!\n";
	      		cout<<"Please proceed to the next question"<<endl;
	      		colour1 = 1;                               //storing information using integer
	      	}
	      	else 
	      	{
	      	    cout<<"That is incorrect\n";
	      	    cout<<"Please proceed to the next question";
	      	}
	      	Sleep(2000);
	      	system("cls");
			      
	      	system ("color A");
	      	cout<<" * * * *    * * * *   * * * *    "<<endl;
	      	cout<<" *     *    *         *      *   "<<endl;
  	      	cout<<" *     *    *         *      *   "<<endl;
	      	cout<<" * * * *    * * * *   *      *   "<<endl;
	      	cout<<" *  *       *         *      *   "<<endl;
	      	cout<<" *   *      *         *      *   "<<endl;
	      	cout<<" *    *     * * * *   * * * *    "<<endl;
	        cout<<" Now, please input the color that you see\n";
			cout<<" Select '1' for Green\n";
	      	cout<<"        '2' for Red\n";
	      	cout<<"        '3' for Blue\n";
	      	cout<<"        '4' for Yellow\n";  
		    cin>>inputcolor2;  
		    //Results
		    if( inputcolor2 == 1)
	      	{
	      		cout<<"That is absolutely correct!\n";
	      		cout<<"Please proceed to the next question\n";
	      		colour2 = 1;                                 //storing information using integer
	      	}
	      	else 
	      	{
	      	    cout<<"That is incorrect\n";
	      	    cout<<"Please proceed to the next question\n"<<endl;
	      	}
	      	
	      	//calculation
	      	totalcolour = colour1 + colour2;
	      	//results
	      	
	      	if( totalcolour == 2)
	      	{
	      	cout<<"RESULTS: You pass the colour test!!\n";
	      	std::ofstream outfile;

          outfile.open("certification.txt", std::ios_base::app);                 //print text for certificate later
          outfile << "Your result for the eye colour test is : You pass the colour test!!"<<endl;
	      }
	      	else
	      	{
	      	cout<<"RESULTS: You did not pass the colour test!!\n";
	      	std::ofstream outfile;

          outfile.open("certification.txt", std::ios_base::app);                 //print text for certificate later
           outfile << "Your result for the eye colour test is : You did not pass the colour test!!"<<endl;
	      }
	      	cout<<"Returning to homepage..."<<endl;
	        Sleep(4000);
	        system("cls");
	       return;
          
	      break;
	    
	    //Shape test starts here
	      case 2:
	
	      	cout<<" Thanks for choosing the Shape Test\n";
	        cout<<" To continue, kindly ";
	         system ("pause");
	         system("cls");
	         
	//first question
	cout<<"\n\n\n Question 1:"<<endl;
	int size = 6 ;                  //printing diamond image

    int z=1;
  for ( int i=0; i<=size; i++)
  {
    for (int j=size; j>i; j--)
    {
      cout<<" "; // printing space here
    }

    cout<<"*";  // printing asterisk here

    if ( i>0)
    {
      for ( int k=1; k<=z; k++)
      {
        cout<<" ";
      }
      z+=2;
      cout<<"*";
    }
    cout<<endl; // end line similar  to \n
  }

  z-=4;

  for (int i=0; i<=size-1; i++)
  {
    for (int j=0; j<=i; j++)
    {
      cout<<" ";
    }

    cout<<"*";

    for (int k=1; k<=z; k++)
    {
      cout<<" ";
    }
    z-=2;

    if (i!=size-1)
    {
      cout<<"*";
    }
    cout<<endl;
  }
	cout<<"\n\n Name the shape above."<<endl;
	cout<<" Now, please input the shape that you see\n";
			cout<<" Select '1' for Diamond\n";
	      	cout<<"        '2' for Square\n";
	      	cout<<"        '3' for Circle\n";
	      	cout<<"        '4' for Triangle\n";  
	cin>>answer1;                        //input
	
	if(answer1 == 1)
	{
		color1 = 0;                                           //storing information using integer
		ofstream myfile("correctcolor.txt");                     //using ofstream to write into file
		myfile<<"You have guessed question 1 correctly.\n";
		myfile.close ();
	}
	else 
	{
	color1 = 1;                                                //storing information using integer
	ofstream myfile("wrongcolor.txt");                              //using ofstream to write into file
	
		myfile<<"You have guessed question 1 incorrectly.\n";
		myfile.close ();
	}
    cout<<"Please wait..."<<endl;
	Sleep(2000);
	system("cls");
	//second question
	cout<<" \n\n\n Question 2 :"<<endl;
	 int r = 1 ;                   //printing triangle

  for (int i=0; i<7; i++)
  {
    for (int j=7; j>i; j--)
    {
      cout<<" "; // displaying space here
    }
    cout<<"*";   // displaying asterisk here

    if (i!=0)
    {
      for (int k=1; k<=r; k++)
      {
        cout<<" ";
      }
      cout<<"*";
      r+=2;
    }
    cout<<endl;  // endl is for new line
  }

  for (int i=0; i<=r+1; i++)
  {
    cout<<"*";
  }

	cout<<"\n\n Name the alphabet above."<<endl;
	cout<<" Now, please input the shape that you see\n";
			cout<<" Select '1' for Circle\n";
	      	cout<<"        '2' for Square\n";
	      	cout<<"        '3' for Triangle\n";
	      	cout<<"        '4' for Pyramid\n";  
	cin>>answer2;
	
	if(answer2 == 3)
	{
		color2 = 0;
		std::ofstream outfile;

    outfile.open("correctcolor.txt", std::ios_base::app);
    outfile << "You have guessed question 2 correctly.\n";
	}
	else 
	{ 
	color2 = 1;
	std::ofstream outfile;

    outfile.open("wrongcolor.txt", std::ios_base::app);
    outfile << "You have guessed question 2 incorrectly.\n";
    
    }
    cout<<"Please wait..."<<endl;
	Sleep(2000);
	system("cls");
	
	//question 3
	cout<<" \n\n\n Question 3 :"<<endl;
	int number = 4;
    int row = 0;
    int col = 0;
    while (row < number)
    {
        col = 0;
        while (col < number)
        {
            cout << "  *";
            col++;
        }
        cout << endl;
        row++;
    }
    cout << endl;
    row++;
	cout<<"\n\n Name the alphabet above."<<endl;
	cout<<" Now, please input the shape that you see\n";
			cout<<" Select '1' for Triangle\n";
	      	cout<<"        '2' for Square\n";
	      	cout<<"        '3' for Circle\n";
	      	cout<<"        '4' for Pyramid\n";  
	cin>>answer3;
	
	if(answer3 == 2)
	{
		color3 = 0;
		std::ofstream outfile;

    outfile.open("correctcolor.txt", std::ios_base::app);
    outfile << "You have guessed question 3 correctly.\n";
    
	}
	else 
	{ 
	color3 = 1;
	std::ofstream outfile;

    outfile.open("wrongcolor.txt", std::ios_base::app);
    outfile << "You have guessed question 3 incorrectly.\n";
    
    }
    
	      break; 
 }
	      //calculation
	      colormarks = color1 + color2 + color3;
	      
	      //display info
	     
	string colorcorrect;
	ifstream myfile ("correctcolor.txt");              //Using ifstream to read text from file
	while(getline (myfile,colorcorrect))
	{
		cout<<"RESULTS:"<<colorcorrect<<'\n';
	}
	myfile.close();
    
    string colorwrong;
	ifstream Myfile ("wrongcolor.txt");                //Using ifstream to read text from file
	while(getline (Myfile,colorwrong))
	{
		cout<<"RESULTS:"<<colorwrong<<'\n';
	}
	Myfile.close();
	
	 //display the final results
	 
	if(colormarks == 0)
	{
		cout<<"You have answered 3 out of 3 questions correctly"<<endl;
		std::ofstream outfile;                                                              //print text for certificate later

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "You have answered 3 out of 3 questions correctly for the eye shape test"<<endl;      
	}
	else if(colormarks == 1)
	{
		cout<<"You have answered 2 out of 3 questions correctly"<<endl;
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "You have answered 2 out of 3 questions correctly for the eye shape test"<<endl;
	}
	else if(colormarks == 2)
	{
		cout<<"You have answered 1 out of 3 questions correctly"<<endl;
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "You have answered 1 out of 3 questions correctly for the eye shape test"<<endl;
	}
	else if (colormarks == 3)
     {
		cout<<"You have answered 0 out of 3 questions correctly"<<endl;
		std::ofstream outfile;

        outfile.open("certification.txt", std::ios_base::app);
        outfile << "You have answered 0 out of 3 questions correctly for the eye shape test"<<endl;
	}
	cout<<"Returning to homepage..."<<endl;
	Sleep(4000);
	system("cls");
	
	  
}
#endif //globalized function

