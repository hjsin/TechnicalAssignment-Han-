#ifndef certification_cpp
#define certification_cpp
#include<iostream>
#include<fstream>
#include<string>
using namespace std;

//globalized function
void certification ()
{ 
//variable
string certifications;
//reads text from file
	ifstream myfile ("certification.txt");
	while (getline (myfile,certifications))
	{
		cout<<"RESULTS:"<<certifications<<'\n';
	}
	myfile.close();
	
	system("pause");
 
}
#endif //globalized function
 
 

