~~Welcome to the FSKPM Automated Health Check-Up~~

Description:
This program serves as an automated self assessment health check-up that consists
of 6 options which are the BMI test, Pulse Rate test, Hearing Test, Eye Test, Manage Accounts
and printing a certificate. We believe that someday, long queues for health check-ups can be avoided
and people around will start living a healthy lifestyle. A healthier world starts from a healthier you. 
Therefore, what are you waiting for? Run the program and check your health today!

Instructions:
1) Before starting the program, please make sure the following text files are empty:
    a) certification.txt
    b) wrongcolor.txt
    c) correctcolor.txt
    d) account.txt

2)Once you are done with step 1, you may proceed to run "main structure.exe" to use the program.

3)Enjoy and have fun! :)